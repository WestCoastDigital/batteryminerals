'use strict';
( function( $ ) {
	$( function() {
        var $results = '#easyPaginate ul';

		$( $results ).pagi( 5 );
		$( '.next' ).on( 'click', function() {
			$( $results ).pagiNext( 5 );
		} );
		$( '.previous' ).on( 'click', function() {
			$( $results ).pagiPrev( 5 );
		} );
		$( '.show-all' ).on( 'click', function() {
			$( $results ).showAll();
		} );
	} );
} )( jQuery );
