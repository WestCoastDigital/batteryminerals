<?php
/*
Plugin Name: Insight EasyPagination
Description: Easily adds pagination
Version:     1.0.0
Author:      Insight
Plugin URI:  
Author URI:
*/

function iep_enqueue() {   
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'jquery.easypaginate', plugin_dir_url( __FILE__ ) . 'assets/jquery.easyPaginate.js' );
    wp_enqueue_script( 'easypaginate', plugin_dir_url( __FILE__ ) . 'assets/easyPaginate.js' );
}
add_action('wp_enqueue_scripts', 'iep_enqueue');
